# some old scratch work
